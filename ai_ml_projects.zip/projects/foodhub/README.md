# FoodHub — Food Delivery Data Analysis

Analyzes restaurant demand, customer ratings, order costs, and preparation and delivery times to develop business recommendations.

## Methods and Highlights

- Explored 1,898 food orders, including cuisine preferences and weekday/weekend demand.
- Compared preparation and delivery times, identified highly rated restaurants, and calculated commission revenue.
- The report identifies 736 unrated orders and approximately 10% of orders taking more than 60 minutes from preparation through delivery.

## View the Project

[Download the HTML report](report.html) to see the code, figures, saved outputs, and analysis. GitHub displays HTML as source; download the file and open it in a browser to view the formatted notebook export.

## Tools

pandas, NumPy, Matplotlib, Seaborn.

## Data and Reproducibility

Required source data: **foodhub_order.csv**. The data and original `.ipynb` notebook are not included in this folder. Obtain the course-provided data separately and add the original notebook when available. Update workstation or Colab paths before running it. The HTML report is a saved analysis, not an executable notebook.

Use the original notebook's dependency setup when reproducing the work; a tested package lockfile has not been supplied.

## Project Context

Prepared from an educational project export supplied by Janane Sivakumar. Metrics and findings above are reported in that export and were not re-run while assembling this repository.
