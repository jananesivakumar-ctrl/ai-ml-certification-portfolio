# HelmNet — Safety Helmet Image Classification

Classifies worker images as With Helmet or Without Helmet using a CNN baseline and VGG16 transfer learning.

## Methods and Highlights

- Uses 4,125 images: 3,161 With Helmet and 964 Without Helmet, with stratified train/validation/test splits.
- Compared a CNN from scratch, VGG16 base, VGG16 with a feedforward head, and an augmented VGG16 variant.
- The selected VGG16 + feedforward model reports approximately 89.7% test accuracy, ROC-AUC of 0.9529, and Without Helmet recall of approximately 0.83.

## View the Project

[Download the HTML report](report.html) to see the code, figures, saved outputs, and analysis. GitHub displays HTML as source; download the file and open it in a browser to view the formatted notebook export.

## Tools

Python, TensorFlow/Keras, OpenCV, scikit-learn, pandas, NumPy, Matplotlib, Seaborn.

## Data and Reproducibility

Required source data: **images.npy and labels.csv**. The data and original `.ipynb` notebook are not included in this folder. Obtain the course-provided data separately and add the original notebook when available. Update workstation or Colab paths before running it. The HTML report is a saved analysis, not an executable notebook.

Use the original notebook's dependency setup when reproducing the work; a tested package lockfile has not been supplied.

## Evaluation Notes

This is image classification, rather than object localization or a demonstrated live video monitoring deployment.

## Project Context

Prepared from an educational project export supplied by Janane Sivakumar. Metrics and findings above are reported in that export and were not re-run while assembling this repository.
