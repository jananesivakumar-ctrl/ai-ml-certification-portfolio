# ReneWind — Wind Turbine Failure Prediction

Predicts wind turbine generator failures from anonymized sensor features, emphasizing recall to reduce missed failures.

## Methods and Highlights

- The supplied dataset has 40 predictors, 20,000 training observations, and 5,000 test observations.
- Compared six neural network variants using different depths, SGD/Adam optimizers, dropout, and class weights.
- The selected class-weighted model reports validation recall of 0.8874 and test recall of 0.8723 for generator failures.

## View the Project

[Download the HTML report](report.html) to see the code, figures, saved outputs, and analysis. GitHub displays HTML as source; download the file and open it in a browser to view the formatted notebook export.

## Tools

pandas, NumPy, scikit-learn, TensorFlow/Keras, SciPy, XGBoost, Matplotlib, Seaborn.

## Data and Reproducibility

Required source data: **Train.csv and Test.csv**. The data and original `.ipynb` notebook are not included in this folder. Obtain the course-provided data separately and add the original notebook when available. Update workstation or Colab paths before running it. The HTML report is a saved analysis, not an executable notebook.

Use the original notebook's dependency setup when reproducing the work; a tested package lockfile has not been supplied.

## Evaluation Notes

The repair, replacement, and inspection cost ordering motivates recall-focused modeling. Actual maintenance savings were not measured in this portfolio preparation.

## Project Context

Prepared from an educational project export supplied by Janane Sivakumar. Metrics and findings above are reported in that export and were not re-run while assembling this repository.
