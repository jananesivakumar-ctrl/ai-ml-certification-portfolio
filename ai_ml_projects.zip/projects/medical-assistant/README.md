# Medical Assistant — Document-Grounded Question Answering

Builds a retrieval-augmented question-answering prototype over a medical reference PDF and compares baseline, prompted, and document-grounded answers.

## Methods and Highlights

- The exported code loads Qwen/Qwen2.5-0.5B-Instruct and all-MiniLM-L6-v2 embeddings.
- Loads and chunks a medical reference PDF, stores embeddings in Chroma, and retrieves context for response generation.
- Compares chunk sizes, overlaps, similarity versus MMR retrieval, retrieved-document counts, and generation temperatures.
- Includes groundedness and relevance assessment using LLM-generated judgments.

## View the Project

[Download the HTML report](report.html) to see the code, figures, saved outputs, and analysis. GitHub displays HTML as source; download the file and open it in a browser to view the formatted notebook export.

## Tools

Transformers, PyTorch, LangChain, Chroma, sentence-transformers, PyMuPDF, pandas, tiktoken.

## Data and Reproducibility

Required source data: **medical_diagnosis_manual.pdf**. The data and original `.ipynb` notebook are not included in this folder. Obtain the course-provided data separately and add the original notebook when available. Update workstation or Colab paths before running it. The HTML report is a saved analysis, not an executable notebook.

Use the original notebook's dependency setup when reproducing the work; a tested package lockfile has not been supplied.

## Evaluation Notes

Some narrative cells refer to Mistral, while the exported model-loading code specifies Qwen. The code is the basis for the model name above. A section labeled Fine-tuning explores retrieval configuration rather than demonstrating model-weight fine-tuning. LLM self-evaluation is not independent clinical validation; this is an educational prototype.

## Project Context

Prepared from an educational project export supplied by Janane Sivakumar. Metrics and findings above are reported in that export and were not re-run while assembling this repository.
