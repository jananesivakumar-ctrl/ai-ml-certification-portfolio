# Personal Loan — Campaign Response Prediction

Predicts personal loan campaign acceptance from customer demographic and financial features to inform marketing segmentation.

## Methods and Highlights

- Compared logistic regression and decision tree classifiers, including a balanced logistic regression baseline.
- Applied cross-validated pre-pruning and cost-complexity post-pruning, and inspected decision rules and feature importance.
- The notebook reports ROC-AUC of approximately 0.96 and recall of approximately 0.65 in its recommendations.

## View the Project

[Download the HTML report](report.html) to see the code, figures, saved outputs, and analysis. GitHub displays HTML as source; download the file and open it in a browser to view the formatted notebook export.

## Tools

pandas, NumPy, scikit-learn, Matplotlib, Seaborn.

## Data and Reproducibility

Required source data: **Loan_Modelling.csv**. The data and original `.ipynb` notebook are not included in this folder. Obtain the course-provided data separately and add the original notebook when available. Update workstation or Colab paths before running it. The HTML report is a saved analysis, not an executable notebook.

Use the original notebook's dependency setup when reproducing the work; a tested package lockfile has not been supplied.

## Evaluation Notes

The notebook selects the post-pruning parameter using test-set ROC-AUC. That set therefore participates in model selection; use a separate validation set or nested cross-validation before treating the reported score as an independent final estimate.

## Project Context

Prepared from an educational project export supplied by Janane Sivakumar. Metrics and findings above are reported in that export and were not re-run while assembling this repository.
