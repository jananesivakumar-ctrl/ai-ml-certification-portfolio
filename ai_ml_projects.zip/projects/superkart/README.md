# SuperKart — Retail Sales Prediction and Deployment

Predicts product-store sales using ensemble regression and documents a Flask API, Streamlit interface, and Docker deployment workflow on Hugging Face Spaces.

## Methods and Highlights

- Analyzed 8,763 records and engineered product-category and store-age features.
- Compared and tuned Random Forest and XGBoost regression pipelines.
- The report selects tuned Random Forest and reports test RMSE of approximately 277.66, MAE of 104.80, and R² of 0.932.
- Includes model serialization and backend/frontend deployment code within the HTML report.

## View the Project

[Download the HTML report](report.html) to see the code, figures, saved outputs, and analysis. GitHub displays HTML as source; download the file and open it in a browser to view the formatted notebook export.

## Tools

pandas, NumPy, scikit-learn, XGBoost, joblib, Flask, Streamlit, requests, huggingface-hub, Matplotlib, Seaborn.

## Data and Reproducibility

Required source data: **SuperKart.csv**. The data and original `.ipynb` notebook are not included in this folder. Obtain the course-provided data separately and add the original notebook when available. Update workstation or Colab paths before running it. The HTML report is a saved analysis, not an executable notebook.

Use the original notebook's dependency setup when reproducing the work; a tested package lockfile has not been supplied.

## Evaluation Notes

Hugging Face access tokens were removed from this distribution. The original tokens should be revoked or rotated. Live deployment status was not verified. The report uses test performance for final model comparison, so those scores are not an untouched estimate after selection.

## Project Context

Prepared from an educational project export supplied by Janane Sivakumar. Metrics and findings above are reported in that export and were not re-run while assembling this repository.
