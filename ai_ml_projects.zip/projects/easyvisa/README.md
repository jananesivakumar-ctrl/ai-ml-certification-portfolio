# EasyVisa — Application Outcome Classification

Compares tree-based classifiers and resampling strategies for predicting the case status in an educational visa-certification dataset.

## Methods and Highlights

- Compared decision tree, bagging, random forest, AdaBoost, gradient boosting, and XGBoost classifiers.
- Evaluated original data, SMOTE oversampling, and random undersampling, with preprocessing pipelines and hyperparameter tuning.
- The notebook selects tuned gradient boosting and reports validation F1 of 0.8204 and test accuracy of 0.7467.

## View the Project

[Download the HTML report](report.html) to see the code, figures, saved outputs, and analysis. GitHub displays HTML as source; download the file and open it in a browser to view the formatted notebook export.

## Tools

pandas, NumPy, scikit-learn, imbalanced-learn, XGBoost, Matplotlib, Seaborn.

## Data and Reproducibility

Required source data: **EasyVisa.csv**. The data and original `.ipynb` notebook are not included in this folder. Obtain the course-provided data separately and add the original notebook when available. Update workstation or Colab paths before running it. The HTML report is a saved analysis, not an executable notebook.

Use the original notebook's dependency setup when reproducing the work; a tested package lockfile has not been supplied.

## Evaluation Notes

The notebook summary compares test accuracy when describing model selection. A fresh held-out set would be needed for an independent final evaluation after that comparison. This project analyzes the supplied dataset; it does not establish real-world application eligibility.

## Project Context

Prepared from an educational project export supplied by Janane Sivakumar. Metrics and findings above are reported in that export and were not re-run while assembling this repository.
